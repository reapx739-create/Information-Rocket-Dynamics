"""
V9.0 闭环控制实验脚本
在本地8GB RTX 4070上跑通无模型自适应PID控制器的闭环验证
生成两张核心论文图表
"""

import json
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
from controller import ModelFreeAdaptiveController
from ollama_utils import chat_one_token, append_assistant_token

# ===== 实验配置 =====
MODEL = "qwen2.5:7b"          # 本地模型名称（7B Q4_K_M量化版，占用约4.7GB显存）
PROMPT = "Why do humans use mathematics to describe nature?"
N_TRAJECTORIES = 5             # 轨迹数量
MAX_TOKENS = 80                # 每条轨迹最大token数

# 控制器参数（基于V8.4在T=0.65下对P2_reasoning的标定）
MU_CRITICAL = 0.28
SIGMA_CRITICAL = 0.04
BETA = 0.18

# 初始化控制器
controller = ModelFreeAdaptiveController(MU_CRITICAL, SIGMA_CRITICAL, BETA)


def generate_controlled_trajectory(traj_id):
    """生成一条受控轨迹：逐 token + 顶层 logprobs + 闭环控温"""
    session = controller.create_session()
    messages = [{"role": "user", "content": PROMPT}]
    history = []
    temp = controller.T_critical

    for step_idx in range(MAX_TOKENS):
        try:
            token, raw_logprobs = chat_one_token(MODEL, messages, temp)
            if not token:
                print(f"[警告] 轨迹{traj_id} 第{step_idx}步返回空token，提前结束")
                break

            append_assistant_token(messages, token)
            if len(messages) > 22:
                messages = messages[:1] + messages[-20:]

            flat_lp = controller.normalize_logprobs(raw_logprobs)
            temp, session = controller.process_streaming_chunk(flat_lp, session)

            history.append({
                "traj": traj_id,
                "step": session["step"],
                "token": token,
                "temp": temp,
                "entropy": session["last_H"],
                "M_t": session["M_t"],
                "S_t": session["S_t"],
            })

            if step_idx % 20 == 19:
                print(f"    轨迹{traj_id} token {step_idx + 1}/{MAX_TOKENS} T={temp:.3f} H={session['last_H']}")

        except Exception as e:
            print(f"[警告] 轨迹{traj_id} 第{step_idx}步出错: {e}")
            continue

        if session["step"] >= MAX_TOKENS:
            break

    return history


def generate_baseline_trajectory(traj_id):
    """生成一条无控制基线轨迹（固定T=0.65，逐 token）"""
    messages = [{"role": "user", "content": PROMPT}]
    history = []

    for step_idx in range(MAX_TOKENS):
        try:
            token, raw_logprobs = chat_one_token(MODEL, messages, 0.65)
            if not token:
                print(f"[警告] 基线轨迹{traj_id} 第{step_idx}步返回空token，提前结束")
                break

            append_assistant_token(messages, token)
            if len(messages) > 22:
                messages = messages[:1] + messages[-20:]

            H_t = controller.entropy_from_logprobs(raw_logprobs)
            history.append({
                "traj": traj_id,
                "step": step_idx + 1,
                "token": token,
                "entropy": H_t if H_t is not None else 0.0,
            })

        except Exception as e:
            print(f"[警告] 基线轨迹{traj_id} 第{step_idx}步出错: {e}")
            continue

    return history


def _plot_series(ax, x, y, *args, **kwargs):
    """仅绘制有效熵值点；无数据时显示提示"""
    valid = [(xi, yi) for xi, yi in zip(x, y) if yi is not None]
    if valid:
        xv, yv = zip(*valid)
        ax.plot(xv, yv, *args, **kwargs)
    else:
        ax.text(0.5, 0.5, "No entropy data", ha="center", va="center", transform=ax.transAxes)


# ===== 主实验流程 =====
if __name__ == "__main__":
    print(f"[{datetime.now().strftime('%H:%M:%S')}] 开始V9.0闭环控制实验...")
    print(f"模型: {MODEL}")
    print(f"模式: 逐token (num_predict=1) + 顶层logprobs")
    print(f"显存占用预估: ~4.7GB (Q4_K_M量化)")
    print(f"控制器参数: mu={MU_CRITICAL}, sigma={SIGMA_CRITICAL}, beta={BETA}")
    print(f"施密特阈值: θ_high={controller.theta_high:.4f}, θ_low={controller.theta_low:.4f}")
    print("-" * 60)

    # ===== 实验组：受控轨迹 =====
    print("\n[实验组] 生成受控轨迹...")
    all_controlled = []
    for i in range(N_TRAJECTORIES):
        traj = generate_controlled_trajectory(i)
        all_controlled.extend(traj)
        final_temp = traj[-1]["temp"] if traj else controller.T_critical
        print(f"  轨迹 {i + 1}/{N_TRAJECTORIES} 完成，{len(traj)}步，最终温度={final_temp:.3f}")

    # ===== 对照组：无控制基线 =====
    print("\n[对照组] 生成基线轨迹（固定T=0.65）...")
    all_baseline = []
    for i in range(N_TRAJECTORIES):
        traj = generate_baseline_trajectory(i)
        all_baseline.extend(traj)
        print(f"  基线轨迹 {i + 1}/{N_TRAJECTORIES} 完成，{len(traj)}步")

    # ===== 保存数据 =====
    results = {
        "controlled": all_controlled,
        "baseline": all_baseline,
        "params": {
            "model": MODEL,
            "mu_critical": MU_CRITICAL,
            "sigma_critical": SIGMA_CRITICAL,
            "beta": BETA,
            "theta_high": controller.theta_high,
            "theta_low": controller.theta_low,
            "T_anchor": controller.T_anchor,
            "T_critical": controller.T_critical,
            "lambda_decay": controller.lambda_decay,
            "n_trajectories": N_TRAJECTORIES,
            "max_tokens": MAX_TOKENS,
        },
    }

    with open("d:/py/v9.0/closed_loop_data.json", "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print("\n数据已保存至 d:/py/v9.0/closed_loop_data.json")

    # ===== 图1：流式熵值时序与施密特门控曲线 =====
    print("\n生成图1：施密特门控曲线...")

    x_c = list(range(len(all_controlled)))
    H_vals = [d["entropy"] for d in all_controlled]
    S_vals = [d["S_t"] for d in all_controlled]
    T_vals = [d["temp"] for d in all_controlled]

    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(14, 10), sharex=True)

    _plot_series(ax1, x_c, H_vals, "b-", alpha=0.7, linewidth=1, label="Shannon Entropy H(t)")
    ax1.axhline(
        y=controller.theta_high,
        color="red",
        linestyle="--",
        label=f"θ_high={controller.theta_high:.3f}",
    )
    ax1.axhline(
        y=controller.theta_low,
        color="orange",
        linestyle="--",
        label=f"θ_low={controller.theta_low:.3f}",
    )
    ax1.set_ylabel("Entropy H(t)")
    ax1.legend(loc="upper right")
    ax1.grid(True, alpha=0.3)
    ax1.set_title("V9.0 Closed-Loop Adaptive Control — Streaming Entropy")

    ax2.fill_between(x_c, 0, S_vals, step="post", color="green", alpha=0.3)
    ax2.plot(x_c, S_vals, "g-", linewidth=2, drawstyle="steps-post")
    ax2.set_ylabel("Gate State S(t)")
    ax2.set_ylim(-0.1, 1.1)
    ax2.set_yticks([0, 1])
    ax2.set_yticklabels(["SAFE (0)", "CONTROL (1)"])
    ax2.grid(True, alpha=0.3)

    ax3.plot(x_c, T_vals, "r-", linewidth=2, label="Temperature T(t)")
    ax3.axhline(
        y=controller.T_anchor,
        color="blue",
        linestyle="--",
        alpha=0.5,
        label=f"T_anchor={controller.T_anchor}",
    )
    ax3.axhline(
        y=controller.T_critical,
        color="purple",
        linestyle="--",
        alpha=0.5,
        label=f"T_critical={controller.T_critical}",
    )
    ax3.set_xlabel("Global Token Index (Controlled)")
    ax3.set_ylabel("Temperature T(t)")
    ax3.legend(loc="upper right")
    ax3.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig("d:/py/v9.0/fig1_schmitt_gate.png", dpi=300)
    print("图1已保存至 d:/py/v9.0/fig1_schmitt_gate.png")

    # ===== 图2：阻尼控温 vs 基线对比 =====
    print("\n生成图2：控温vs基线对比...")

    controlled_H = [d["entropy"] for d in all_controlled if d["entropy"] is not None]
    baseline_H = [d["entropy"] for d in all_baseline if d["entropy"] is not None]

    fig2, ax = plt.subplots(figsize=(14, 6))
    if controlled_H:
        ax.plot(
            range(len(controlled_H)),
            controlled_H,
            "b-",
            alpha=0.6,
            linewidth=0.8,
            label="Controlled (Adaptive PID)",
        )
    if baseline_H:
        ax.plot(
            range(len(baseline_H)),
            baseline_H,
            "r-",
            alpha=0.6,
            linewidth=0.8,
            label="Baseline (Fixed T=0.65)",
        )
    ax.set_xlabel("Token Step")
    ax.set_ylabel("Entropy")
    ax.set_title("V9.0 Entropy Comparison: Controlled vs Baseline")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig("d:/py/v9.0/fig2_entropy_comparison.png", dpi=300)
    print("图2已保存至 d:/py/v9.0/fig2_entropy_comparison.png")

    # ===== 统计摘要 =====
    ctrl_H = [d["entropy"] for d in all_controlled if d["entropy"] is not None]
    base_H = [d["entropy"] for d in all_baseline if d["entropy"] is not None]
    gate_on = sum(1 for d in all_controlled if d["S_t"] == 1)

    print("\n" + "=" * 60)
    print("V9.0 闭环控制实验完成")
    print("=" * 60)
    print(f"总步数: {len(all_controlled)} (受控) + {len(all_baseline)} (基线)")
    print(f"受控轨迹数: {N_TRAJECTORIES}，基线轨迹数: {N_TRAJECTORIES}")
    if ctrl_H:
        print(f"受控熵: mean={np.mean(ctrl_H):.4f} std={np.std(ctrl_H):.4f} min={min(ctrl_H):.4f} max={max(ctrl_H):.4f}")
    if base_H:
        print(f"基线熵: mean={np.mean(base_H):.4f} std={np.std(base_H):.4f} min={min(base_H):.4f} max={max(base_H):.4f}")
    print(f"施密特门控触发步数: {gate_on}/{len(all_controlled)}")
    print("图表位置: d:/py/v9.0/")
    print("数据位置: d:/py/v9.0/closed_loop_data.json")
    print("=" * 60)
