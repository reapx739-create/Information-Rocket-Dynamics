# Offline preview - no Markdown extension, no network
$paperDir = $PSScriptRoot
$mdPath = Join-Path $paperDir "manuscript.md"
$outPath = Join-Path $paperDir "review_offline.html"

if (-not (Test-Path $mdPath)) { Write-Host "manuscript.md not found"; exit 1 }

$md = Get-Content $mdPath -Raw -Encoding UTF8
$escaped = $md -replace '&', '&amp;' -replace '<', '&lt;' -replace '>', '&gt;'

$html = @"
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<title>V9.0 Preprint Review</title>
<style>
body{font-family:Georgia,serif;max-width:780px;margin:2rem auto;padding:0 1.2rem;line-height:1.65;background:#fafafa}
.banner{background:#e8f4fc;border:1px solid #7eb8da;padding:12px;margin-bottom:20px;font-family:sans-serif;font-size:14px}
pre{white-space:pre-wrap;word-wrap:break-word;font-size:13px;background:#fff;border:1px solid #ddd;padding:16px}
</style>
</head>
<body>
<div class="banner"><b>Offline review</b> = manuscript.md. Edit md, run build_preview.ps1 again.</div>
<pre>$escaped</pre>
</body>
</html>
"@

[System.IO.File]::WriteAllText($outPath, $html, [System.Text.UTF8Encoding]::new($false))
Write-Host "OK: $outPath"
Start-Process $outPath
