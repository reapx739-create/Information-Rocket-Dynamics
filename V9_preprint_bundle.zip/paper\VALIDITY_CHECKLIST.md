# Validity Checklist — Phase Sign-Off

**Phase goal:** A paper that can be posted online and survives validity scrutiny.  
**Sign-off criterion:** Every row below has a **written answer** in `manuscript.md` §2–§4 and a **traceable artifact**.

| # | Reviewer question | Answer location | Artifact |
|---|-------------------|-----------------|----------|
| 1 | What exactly is $H_t$? | §2.2 | `controller.py` → `entropy_from_logprobs` |
| 2 | Is top-$K$ bias fatal? | §2.2, §4 | Same $K$ both arms; appendix TODO for $K$-sweep |
| 3 | Why $T_{\mathrm{critical}}=0.65$? | §2.3 | `risk_vs_T.png` (V8) |
| 4 | Why Schmitt, not PID? | §2.5, §4 | `hysteresis.png` (V8) |
| 5 | Why these $\theta$ values? | §2.5 | V8.4 bootstrap ($\mu,\sigma$) in code comments |
| 6 | Is baseline fair? | §2.7, §4 | Fixed $T{=}0.65$ = calibrated probe point |
| 7 | One prompt only? | §2.4, §2.7 | P1–P10 figures + scope statement |
| 8 | Effect size? | §3.4 | `closed_loop_data.json` → peak −13.4%, mean −3.4% |
| 9 | Reproducible? | §5 | `v9.0_closed_loop.py`, Ollama version, JSON |
| 10 | What is *not* claimed? | §4 | No human eval / task accuracy claim |

**Phase complete when:** `manuscript.md` + figures + JSON are uploaded (arXiv / Zenodo / personal site) with a public URL.

---

## Upload Checklist (≈30 minutes)

- [ ] Zip: `paper/manuscript.md`, `fig1_schmitt_gate.png`, `fig2_entropy_comparison.png`, `closed_loop_data.json`, key V8 PNGs
- [ ] arXiv: convert MD → LaTeX/PDF (or upload PDF exported from Word)
- [ ] Zenodo: same zip → DOI
- [ ] README in repo root pointing to URL

---

## Optional before journal (not blocking preprint)

- [ ] Bootstrap 95% CI on peak-entropy reduction
- [ ] $K$-sensitivity paragraph
- [ ] Exact $\chi^2$ reference distribution sentence in §2.3
- [ ] Human or automatic quality metric (1 paragraph)
