# V9.0 Preprint Bundle

## Phase sign-off

**Done =** `manuscript.md` publicly reachable + artifacts listed in `VALIDITY_CHECKLIST.md`.

## Files

| File | Role |
|------|------|
| `manuscript.md` | Full English draft (Abstract → Reproducibility) |
| `VALIDITY_CHECKLIST.md` | Reviewer Q&A map for validity |
| `../closed_loop_data.json` | Raw V9.0 step log |
| `../fig1_schmitt_gate.png` | Figure: actuation |
| `../fig2_entropy_comparison.png` | Figure: controlled vs baseline |

## Quick publish paths

1. **PDF** — `pdflatex main.tex` (twice) in this folder → `main.pdf`
2. **arXiv** — copy fields from `arxiv_submit.txt`; upload `main.pdf` + source
3. **GitHub + Zenodo** — zip `paper/`, both PNGs, `closed_loop_data.json`, code

| File | Role |
|------|------|
| `main.tex` | LaTeX source (figures: `../fig1_*.png`) |
| `arxiv_submit.txt` | Title, abstract, categories — paste into arXiv form |
| `manuscript.md` | Markdown twin (same content) |

## Regenerate V9.0 numbers

```powershell
cd d:/py/v9.0
python v9.0_closed_loop.py
```

Requires Ollama on `http://localhost:11434` with `qwen2.5:7b`.
