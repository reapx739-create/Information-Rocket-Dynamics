# Phase 2：正式论文改造（Preprint → Submission-Ready）

**Phase 1 已完成：** GitHub 公开 + Methods 骨架 + V9.0 复现包  
**Phase 2 目标：** 可投 workshop / 预印本期刊 / arXiv PDF 的完整英文稿

---

## 与预印本的区别

| 维度 | Phase 1（现在） | Phase 2（正式稿） |
|------|-----------------|-------------------|
| Methods | 有，但有 TODO | 公式完整、$\chi^2$ 定义明确、V8/V9 模型分工写清 |
| Results | 摘要式 4 段 | 展开 + Table 1/2 + 逐图段落 |
| Figures | 分散、未统一编号 | Fig.1–10 连续编号 + caption 定稿 |
| 统计 | 仅 mean/std/peak | 可选 bootstrap CI、$\chi^2/df$ 检验表述 |
| 引用 | 占位 | ≥15 条 Related Work |
| 格式 | Markdown | PDF（Overleaf `main.tex`） |

---

## 建议论文叙事（两幕结构）

**Act I — V8.x 表征（为什么需要控制）**  
非单调 $H(T)$、迟滞、P1–P10 相区 → 温度不是线性旋钮

**Act II — V9.0 闭环（怎么控制）**  
Schmitt + 指数松弛 → 13.4% 峰值熵剪裁，均值仅 −3.4%

> 注意：`PAPER_DIGEST.txt` 中 V8.5 表注明 **DeepSeek V4 Pro**；V9.0 为 **Qwen2.5-7B 本地**。正式稿 Methods 必须分两小节写清，避免审稿人质疑「模型不一致」。

---

## 改造任务清单（按优先级）

### P0 — 必做（有效性过关）

- [x] 定稿 $\chi^2$ 定义（相对 $T{=}0.80$ 基线，df=199）
- [x] 写清 V8 探测模型 vs V9 控制模型
- [x] 扩写 Results：Fig.1–10 各一段（`manuscript_formal.md` v0.3）
- [x] 统一 Figure 1–10；`main.tex` 全部 `\includegraphics`
- [x] Abstract 四轮结构

### P1 — 强加分

- [x] Table 1 / Table 2
- [x] Related Work 15 条引用
- [x] Limitations 在 Discussion
- [x] `generate_v8_figures.py` → `paper/figures/`（14 PNG）

### P2 — 投稿前

- [x] `main.tex` 与 `manuscript_formal.md` 同步
- [ ] Overleaf 编译 PDF
- [ ] arXiv 或目标会议模板套版
- [ ] Zenodo DOI + 更新 GitHub README

---

## 工作文件

| 文件 | 用途 |
|------|------|
| `manuscript_formal.md` | **Phase 2 主稿 v0.2**（§3 逐图 Results 已扩写） |
| `main.tex` | 已与 formal 同步（Fig.1–8 占位框，Fig.9–10 实图） |
| `manuscript.md` | Phase 1 存档，可不动 |
| `main.tex` | 最终 PDF 源 |
| `PAPER_DIGEST.txt` | 表格/公式粘贴源 |

---

## 你需要决定的一件事

**投稿目标**（决定篇幅与 Related Work 深度）：

1. **Workshop / 短文**（6–8 页）— 保留两幕结构，图减到 6 张  
2. **arXiv 长文**（12–15 页）— 保留全部 P1–P10 相图  
3. **中文核心/期刊**— 需中英双稿或翻译环节  

回复目标类型后，按该格式压篇幅。
