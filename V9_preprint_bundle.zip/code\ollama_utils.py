"""Ollama HTTP 工具：逐 token 生成 + 顶层 logprobs（Ollama >= 0.12.11）"""

import json
import urllib.request

OLLAMA_CHAT_URL = "http://localhost:11434/api/chat"


def chat_one_token(model, messages, temperature):
    """
    单 token 续写。logprobs 必须放在请求体顶层，不能放在 options 内。
    返回: (token_text, raw_logprobs_list)
    """
    body = {
        "model": model,
        "messages": messages,
        "stream": False,
        "logprobs": True,
        "top_logprobs": 20,
        "options": {
            "num_predict": 1,
            "temperature": temperature,
        },
    }
    payload = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        OLLAMA_CHAT_URL,
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=300) as resp:
        data = json.loads(resp.read().decode("utf-8"))

    token = (data.get("message") or {}).get("content") or ""
    return token, data.get("logprobs")


def append_assistant_token(messages, token):
    """将单 token 追加到对话中的 assistant 消息"""
    if not token:
        return
    if len(messages) == 1:
        messages.append({"role": "assistant", "content": token})
    else:
        messages[-1]["content"] += token
