"""Regenerate V8 probe figures from v84_scan.csv into paper/figures/."""
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CSV = os.path.normpath(os.path.join(_SCRIPT_DIR, "..", "..", "v84_results", "v84_scan.csv"))
OUT = os.path.join(os.path.dirname(__file__), "figures")
os.makedirs(OUT, exist_ok=True)

df = pd.read_csv(CSV)
print(f"Loaded {len(df)} rows from {CSV}")

# --- aggregate vs T ---
for col, ylabel, fname in [
    ("entropy", "Entropy", "entropy_vs_T.png"),
    ("risk", "Risk", "risk_vs_T.png"),
    ("top1_prob", "Top1 Prob", "top1_vs_T.png"),
]:
    means = df.groupby("temperature")[col].mean()
    stds = df.groupby("temperature")[col].std()
    plt.figure(figsize=(8, 5))
    if col == "entropy":
        plt.plot(means.index, means.values, "o-")
    else:
        plt.errorbar(means.index, means.values, yerr=stds.values, marker="o", capsize=3)
    plt.title(f"{ylabel} vs Temperature")
    plt.xlabel("Temperature")
    plt.ylabel(ylabel)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, fname), dpi=150)
    plt.close()

# chi2 vs T (aggregate)
means = df.groupby("temperature")["chi2"].mean()
stds = df.groupby("temperature")["chi2"].std()
plt.figure(figsize=(8, 5))
plt.errorbar(means.index, means.values, yerr=stds.values, marker="o", capsize=3)
plt.title("Chi2 vs Temperature")
plt.xlabel("Temperature")
plt.ylabel("Chi2")
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "chi2_vs_T.png"), dpi=150)
plt.close()

# hysteresis (heating vs cooling risk)
means = df.groupby("temperature")["risk"].mean()
temps = means.index.values
up = means.values
down = up[::-1]
plt.figure(figsize=(8, 5))
plt.plot(temps, up, "o-", label="Heating")
plt.plot(temps, down, "s-", label="Cooling")
plt.fill_between(temps, up, down, alpha=0.3)
plt.title("Hysteresis Loop")
plt.xlabel("Temperature")
plt.ylabel("Risk")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "hysteresis.png"), dpi=150)
plt.close()

# regime density
plt.figure(figsize=(8, 5))
df["regime"].value_counts().plot(kind="bar")
plt.title("Regime Density")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig(os.path.join(OUT, "regime_density.png"), dpi=150)
plt.close()

# phase diagram (all prompts)
plt.figure(figsize=(8, 6))
sc = plt.scatter(df["entropy"], df["chi2"], c=df["temperature"], cmap="plasma", alpha=0.5, s=8)
plt.colorbar(sc, label="T")
plt.xlabel("Entropy")
plt.ylabel("Chi2")
plt.title("Phase Diagram (all prompts)")
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "phase_diagram.png"), dpi=150)
plt.close()

# dynamics plane
plt.figure(figsize=(8, 6))
sc = plt.scatter(
    np.abs(df["d_entropy"]),
    np.abs(df["d_chi2"]),
    c=df["temperature"],
    cmap="viridis",
    alpha=0.5,
    s=8,
)
plt.colorbar(sc, label="T")
plt.xlabel("|ΔEntropy|")
plt.ylabel("|ΔChi2|")
plt.title("|ΔChi2| vs |ΔEntropy|")
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "dynamics_plane.png"), dpi=150)
plt.close()

# boxplots
colors = plt.cm.tab10(np.linspace(0, 1, 10))
for col, title, fname in [
    ("top1_prob", "Top1 Distribution by Prompt", "top1_by_prompt.png"),
    ("chi2", "chi2 Distribution by Prompt", "chi2_by_prompt.png"),
]:
    plt.figure(figsize=(14, 6))
    data = [df[df["prompt_id"] == pid][col].values for pid in range(10)]
    bp = plt.boxplot(data, patch_artist=True)
    for patch, c in zip(bp["boxes"], colors):
        patch.set_facecolor(c)
        patch.set_alpha(0.7)
    plt.xticks(range(1, 11), [f"P{i+1}" for i in range(10)], fontsize=9)
    plt.ylabel(col)
    plt.title(title)
    plt.grid(True, axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, fname), dpi=150)
    plt.close()

# per-prompt phase P2 (id=1) and P8 (id=7)
PROMPTS = [
    "P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10",
]
for pid, label in [(1, "phase_p2.png"), (7, "phase_p8.png")]:
    sub = df[df["prompt_id"] == pid]
    plt.figure(figsize=(7, 6))
    sc = plt.scatter(sub["entropy"], sub["chi2"], c=sub["temperature"], cmap="plasma", alpha=0.6, s=12)
    plt.colorbar(sc, label="T")
    plt.title(f"Phase Diagram — {PROMPTS[pid]} (prompt_id={pid})")
    plt.xlabel("Entropy")
    plt.ylabel("Chi2")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, label), dpi=150)
    plt.close()

# copy V9 figures if present
import shutil

v9 = os.path.join(os.path.dirname(__file__), "..")
for name in ("fig1_schmitt_gate.png", "fig2_entropy_comparison.png"):
    src = os.path.join(v9, name)
    if os.path.isfile(src):
        shutil.copy2(src, os.path.join(OUT, name))

print(f"Done. {len(os.listdir(OUT))} files in {OUT}")
