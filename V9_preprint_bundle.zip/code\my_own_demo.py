"""
V9.0 专属ASCII实时监控Demo
三通道控制面板：生成流 + 认知状态 + 控制信号
"""

import os
import time
import numpy as np
from controller import ModelFreeAdaptiveController
from ollama_utils import chat_one_token, append_assistant_token

MODEL = "qwen2.5:7b"
PROMPT = "Why do humans use mathematics to describe nature?"

controller = ModelFreeAdaptiveController(0.28, 0.04, 0.18)


def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")


def draw_temperature_bar(temp):
    """温度计：0.2 到 1.2 的进度条"""
    normalized = (temp - 0.2) / 1.0
    filled = int(normalized * 20)
    bar = "█" * filled + "░" * (20 - filled)
    return f"[{bar}] {temp:.3f}"


def draw_entropy_sparkline(history, width=40):
    """熵值迷你走势图"""
    if len(history) < 2:
        return "等待数据..."
    recent = history[-min(len(history), 20) :]
    h_min, h_max = min(recent), max(recent)
    if h_max - h_min < 0.01:
        h_min -= 0.01
        h_max += 0.01
    line = ""
    for h in recent:
        pos = int((h - h_min) / (h_max - h_min) * (width - 1))
        line += " " * pos + "▏"
    return f"Min:{h_min:.3f} {line} Max:{h_max:.3f}"


def draw_risk_stars(risk_level):
    """风险指数：五星评级"""
    stars = "★" * risk_level + "☆" * (5 - risk_level)
    return stars


def run_demo():
    session = controller.create_session()
    messages = [{"role": "user", "content": PROMPT}]
    temp = controller.T_critical
    entropy_history = []
    output_text = ""

    print("V9.0 专属Demo启动")
    print(f"模型: {MODEL}")
    print(f"提示词: {PROMPT[:50]}...")
    print("控制器: 施密特门控 + 动量观测 + 指数阻尼")
    print("=" * 60)
    time.sleep(1)

    for step_count in range(60):
        clear_screen()

        try:
            token, raw_logprobs = chat_one_token(MODEL, messages, temp)
            if token:
                output_text += token
                append_assistant_token(messages, token)
                if len(messages) > 22:
                    messages = messages[:1] + messages[-20:]

                flat_lp = controller.normalize_logprobs(raw_logprobs)
                temp, session = controller.process_streaming_chunk(flat_lp, session)
                if session["last_H"] is not None:
                    entropy_history.append(session["last_H"])
        except Exception as e:
            print(f"[错误] {e}")
            continue

        H_t = session["last_H"] if session["last_H"] else 0
        risk_level = min(5, int(abs(session["M_t"]) * 10 + (1 if session["S_t"] == 1 else 0)))

        print("╔══════════════════════════════════════════════════════════╗")
        print("║           V9.0 信息火箭 · 实时驾驶舱                    ║")
        print("╠══════════════════════════════════════════════════════════╣")
        print(f"║ Step: {session['step']:<6}                                       ║")
        print(f"║ 温度计  : {draw_temperature_bar(temp)}                  ║")
        gate_label = "[ON · 控制中]" if session["S_t"] == 1 else "[OFF · 安全]"
        print(f"║ 施密特门控: {gate_label:<30}                    ║")
        print(f"║ 动量 M_t : {session['M_t']:.4f}                                          ║")
        print(f"║ 风险指数 : {draw_risk_stars(risk_level)}                                         ║")
        print("║ 熵值走势 :                                                  ║")
        print(f"║ {draw_entropy_sparkline(entropy_history):<54} ║")
        print("╚══════════════════════════════════════════════════════════╝")
        print(f"\n生成文本:\n{output_text[-200:]}")

        time.sleep(0.3)

        if session["step"] >= 60:
            break

    print("\nDemo结束。感谢试驾信息火箭！")


if __name__ == "__main__":
    run_demo()
