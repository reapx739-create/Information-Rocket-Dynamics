import numpy as np

class ModelFreeAdaptiveController:
    """
    无模型自适应PID控制器
    基于双阈值施密特回滞 + 前向趋势动量观测 + 指数阻尼平滑控制
    专为8GB显存RTX 4070 Laptop优化
    """
    def __init__(self, mu_critical=0.28, sigma_critical=0.04, beta=0.18):
        """
        参数标定来源：V8.4在T=0.65下对P2_reasoning的30次自举采样
        
        mu_critical: 临界相区经验均值
        sigma_critical: 临界相区经验标准差
        beta: 前向预测趋势动量阻尼系数
        """
        # 施密特触发器阈值
        self.theta_high = mu_critical + 1.645 * sigma_critical  # 激活阈值 (90%置信上限)
        self.theta_low = mu_critical                              # 释放阈值 (经验中位数)
        
        # 控制律参数
        self.beta = beta
        self.T_anchor = 0.80      # 稳定防线锚点温度
        self.T_critical = 0.65    # 初始分叉探测温度
        self.lambda_decay = 0.15  # 连续时间阻尼常数

    def create_session(self):
        """创建一个新的无状态控制会话"""
        return {
            'M_t': 0.0,        # 前向趋势动量
            'S_t': 0,          # 施密特触发器状态 (0=安全, 1=高风险)
            'last_H': None,    # 上一步熵值
            'step': 0,         # 当前步数
            't_trigger': 0     # 触发时间戳
        }

    @staticmethod
    def _chunk_get(chunk, key, default=None):
        """兼容 dict 与 ollama ChatResponse"""
        if chunk is None:
            return default
        if isinstance(chunk, dict):
            return chunk.get(key, default)
        if hasattr(chunk, 'get'):
            return chunk.get(key, default)
        return getattr(chunk, key, default)

    @staticmethod
    def normalize_logprobs(logprobs):
        """
        将 Ollama logprobs 转为 [{token, logprob}, ...] 供熵计算使用。
        支持：顶层 logprobs 数组、单步 top_logprobs 嵌套、流式 chunk。
        """
        if not logprobs:
            return None

        if isinstance(logprobs, list) and len(logprobs) == 1:
            entry = logprobs[0]
            if isinstance(entry, dict) and entry.get('top_logprobs'):
                return entry['top_logprobs']

        flat = []
        for lp in logprobs:
            if not isinstance(lp, dict):
                continue
            if lp.get('top_logprobs'):
                flat.extend(lp['top_logprobs'])
            elif 'logprob' in lp or 'log_prob' in lp:
                flat.append(lp)
        return flat if flat else None

    @staticmethod
    def extract_logprobs(chunk):
        """安全提取logprobs，处理多种Ollama API格式"""
        lp_data = ModelFreeAdaptiveController._chunk_get(chunk, 'logprobs')
        if lp_data:
            return ModelFreeAdaptiveController.normalize_logprobs(lp_data)
        msg = ModelFreeAdaptiveController._chunk_get(chunk, 'message', {}) or {}
        if isinstance(msg, dict) and msg.get('logprobs'):
            return ModelFreeAdaptiveController.normalize_logprobs(msg['logprobs'])
        if hasattr(msg, 'logprobs') and msg.logprobs:
            return ModelFreeAdaptiveController.normalize_logprobs(msg.logprobs)
        return None

    @staticmethod
    def entropy_from_logprobs(logprobs):
        """从 logprobs 计算 Shannon 熵"""
        flat = ModelFreeAdaptiveController.normalize_logprobs(logprobs)
        if not flat:
            return None
        probs = {}
        for lp in flat:
            if not isinstance(lp, dict):
                continue
            token = lp.get('token') or lp.get('text', '')
            logprob = lp.get('logprob') or lp.get('log_prob', -10)
            try:
                probs[token] = np.exp(float(logprob))
            except (ValueError, OverflowError):
                continue
        if not probs:
            return None
        total = sum(probs.values())
        if total <= 0:
            return None
        probs = {k: v / total for k, v in probs.items()}
        return float(-sum(p * np.log(max(p, 1e-12)) for p in probs.values()))

    def process_streaming_chunk(self, logprobs, session):
        """
        处理流式生成的单个chunk（修复版：格式容错 + 边界保护）
        
        输入:
            logprobs: API返回的logprobs列表（或None）
            session: 当前会话状态字典
        
        返回:
            T_next: 下一步使用的温度
            session: 更新后的会话状态
        """
        # 1. 格式容错：空值保护
        if not logprobs:
            return (self.T_anchor if session['S_t'] == 1
                    else self.T_critical), session
        
        # 2. 多格式兼容提取概率分布
        probs = {}
        for lp in logprobs:
            if not isinstance(lp, dict):
                continue
            token = lp.get('token') or lp.get('text', '')
            logprob = lp.get('logprob') or lp.get('log_prob', -10)
            try:
                probs[token] = np.exp(float(logprob))
            except (ValueError, OverflowError):
                continue
        
        if not probs:
            return (self.T_anchor if session['S_t'] == 1
                    else self.T_critical), session
        
        total = sum(probs.values())
        if total <= 0:
            return self.T_critical, session
        probs = {k: v/total for k, v in probs.items()}
        H_t = -sum(p * np.log(max(p, 1e-12)) for p in probs.values())
        
        session['step'] += 1
        
        # 2. 首步初始化
        if session['last_H'] is None:
            session['last_H'] = H_t
            session['M_t'] = 0.0
            return self.T_critical, session
        
        # 3. 计算熵值变化量和前向趋势动量
        delta_H = H_t - session['last_H']
        session['M_t'] = self.beta * delta_H + (1 - self.beta) * session['M_t']
        
        # 4. 施密特双阈值回滞状态机
        S_t = session['S_t']
        if S_t == 0 and session['M_t'] > 0 and H_t > self.theta_high:
            S_t = 1
            session['t_trigger'] = session['step']
        elif S_t == 1 and session['M_t'] <= 0 and H_t <= self.theta_low:
            S_t = 0
        
        session['S_t'] = S_t
        
        # 5. 执行机构映射：连续温度控制
        if S_t == 1:
            tau = session['step'] - session['t_trigger']
            T_next = self.T_anchor + (self.T_critical - self.T_anchor) * np.exp(-self.lambda_decay * tau)
        else:
            T_next = self.T_critical
        
        session['last_H'] = H_t
        return T_next, session
