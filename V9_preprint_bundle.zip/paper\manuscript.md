# Prompt-Conditioned Distributional Regimes and Schmitt-Trigger Closed-Loop Temperature Control for Streaming LLM Inference

**Version:** V9.0 preprint draft  
**Status:** Phase-complete validity manuscript (Methods + Results + Reproducibility)  
**Artifacts:** `d:/py/v9.0/` — `controller.py`, `v9.0_closed_loop.py`, `closed_loop_data.json`, `fig1_schmitt_gate.png`, `fig2_entropy_comparison.png`

---

## Abstract

Open-loop temperature scaling is widely treated as a monotonic knob on output randomness. We show—via high-resolution thermodynamic probes (V8.x) and a token-level closed-loop deployment (V9.0)—that streaming LLM inference exhibits **non-monotonic entropy landscapes**, **path-dependent hysteresis**, and **prompt-conditioned phase heterogeneity**. These phenomena invalidate memoryless linear actuation and motivate a **dual-threshold Schmitt trigger** with **exponential relaxation** of the sampling temperature. On `qwen2.5:7b` (Q4_K_M, local Ollama), V9.0 reduces **peak Shannon entropy by 13.4%** versus a fixed-$T{=}0.65$ baseline while changing mean entropy by only **3.4%**, indicating surgical tail clipping rather than global dulling. All metrics, code, and raw step logs are released for reproducibility.

**Keywords:** LLM inference control, Shannon entropy, Schmitt trigger, hysteresis, prompt-conditioned regimes, Ollama logprobs

---

## 1. Introduction

Decoding temperature $T$ is the default actuator for trading fluency against diversity. Practitioners assume that raising $T$ smoothly increases distributional entropy $H$. We falsify this assumption with systematic probes and argue that **valid control** requires (i) calibrated online entropy estimation, (ii) **stateful** gating to respect hysteresis, and (iii) prompt-aware expectations of regime heterogeneity. V9.0 instantiates these requirements as a lightweight, model-free actuator sitting entirely outside the transformer graph.

**Contributions.**

1. Empirical taxonomy of **non-monotonic** $H(T)$, risk peaks, and **heating/cooling hysteresis** in open-loop generation.
2. Prompt-level evidence that $\chi^2$ and Top-1 tails diverge by orders of magnitude across P1–P10 (e.g., P2 outliers up to $\chi^2 \approx 9.5$).
3. A **reproducible** Schmitt–relaxation controller with publicly released step traces showing **54.3%** gate duty and **13.4%** peak-entropy reduction.

---

## 2. Methods

*This section is the validity backbone of the paper. Every claim in §3 is traceable to a definition here.*

### 2.1 System and Software Stack

| Component | Setting |
|-----------|---------|
| Model | `qwen2.5:7b`, Q4_K_M quantization (~4.7 GB weights) |
| Runtime | Ollama ≥ 0.12.11 (tested: 0.24.0), `localhost:11434` |
| Hardware | NVIDIA RTX 4070 Laptop GPU, 8 GB VRAM class |
| API | Native `/api/chat`; `logprobs: true` and `top_logprobs: 20` at **request body top level** (not inside `options`) |
| Token protocol | `num_predict: 1` per step; assistant prefix accumulated in-message |

**Reproducibility.** Scripts: `controller.py`, `ollama_utils.py`, `v9.0_closed_loop.py`. Raw log: `closed_loop_data.json` (400 controlled + 400 baseline steps).

### 2.2 Online Shannon Entropy from Truncated Logprobs

At each generation step $t$, Ollama returns the sampled token and `top_logprobs` list $\mathcal{L}_t$ ($K{=}20$). We form a renormalized distribution over reported candidates:

$$
\tilde{p}_i = \frac{\exp(\ell_i)}{\sum_{j \in \mathcal{L}_t} \exp(\ell_j)}, \qquad
H_t = -\sum_{i \in \mathcal{L}_t} \tilde{p}_i \log \tilde{p}_i
$$

where $\ell_i$ is the log-probability of candidate $i$.

**Construct validity (what $H_t$ is).** $H_t$ is a **lower-bound surrogate** for full-vocabulary entropy, biased by tail mass outside the top-$K$ window. **Controlled and baseline arms use the identical estimator**, so comparative claims (peak clipping, gate duty) are internally valid. Absolute entropy levels should not be compared across $K$ without sensitivity analysis (planned: $K \in \{5,10,20,50\}$ in appendix).

**Implementation.** `ModelFreeAdaptiveController.entropy_from_logprobs` / `normalize_logprobs` in `controller.py`.

### 2.3 Distributional Divergence and Risk (V8 Probes)

**$\chi^2$ divergence.** [Author note: insert exact reference distribution used in V8 pipeline—e.g., uniform over top-$K$, or vs. running mean token distribution.] Reported per $(\text{prompt}, T)$ with error bars over $n{=}30$ runs where applicable.

**Risk signal.** Along temperature sweeps,
$$
R(T) \;=\; \left|\frac{\Delta \chi^2}{\Delta T}\right|
$$
(optionally scaled by $|\Delta H|/ \Delta T$ in composite plots). The global maximum at **$T \approx 0.65$** ($R \approx 0.20$) motivates selecting $T_{\mathrm{critical}} = 0.65$ as the open-loop probing setpoint—not a hyperparameter tuned on V9.0 test trajectories.

**Hysteresis protocol.** Independent **heating** ($T$ ascending) and **cooling** ($T$ descending) traversals on the same prompt manifold produce non-overlapping $R(T)$ envelopes (Fig. hysteresis). This establishes **path dependence**: the instantaneous state depends on thermodynamic history, not $T$ alone.

### 2.4 Prompt Suite (P1–P10)

Ten prompts spanning factual, creative, translation, and open reasoning tasks (titles in phase-diagram figures). **Prompt-conditioned regime heterogeneity:** boxplots show P1/P3/P5-like **collapse** (Top-1 $\rightarrow 1$, $\chi^2 \rightarrow 0$) versus P2/P8-like **divergence** (Top-1 tails to $\approx 0.63$, $\chi^2$ outliers up to $\approx 9.5$). Phase diagrams $(H, \chi^2)$ colored by $T$ confirm that identical $T$ can land on disjoint manifolds—supporting **online** control rather than prompt-offline $T$ alone.

### 2.5 Threshold Calibration (V8.4 → V9.0)

Bootstrap on P2 reasoning at $T{=}0.65$ ($n{=}30$) yields critical-phase statistics:
$\mu_{\mathrm{crit}} = 0.28$, $\sigma_{\mathrm{crit}} = 0.04$.

Schmitt thresholds:
$$
\theta_{\mathrm{low}} = \mu_{\mathrm{crit}}, \qquad
\theta_{\mathrm{high}} = \mu_{\mathrm{crit}} + 1.645\,\sigma_{\mathrm{crit}} \approx 0.346
$$
(one-sided 90% upper confidence on the critical entropy scale).

**Momentum observer** (trend of entropy increments):
$$
M_t = \beta\,(H_t - H_{t-1}) + (1-\beta)\,M_{t-1}, \quad \beta = 0.18
$$

**Gate logic** (state $S_t \in \{0,1\}$ for SAFE / CONTROL):
- **Activate:** $S_t \leftarrow 1$ if $S_{t-1}{=}0$, $M_t > 0$, and $H_t > \theta_{\mathrm{high}}$.
- **Release:** $S_t \leftarrow 0$ if $S_{t-1}{=}1$, $M_t \le 0$, and $H_t \le \theta_{\mathrm{low}}$.

**Why not memoryless PID on $H_t$?** Hysteresis implies that equal $H$ at equal $T$ can carry different downstream risk depending on approach direction; a map $T{=}f(H_t)$ chatter at envelope boundaries. The Schmitt pair $(\theta_{\mathrm{low}}, \theta_{\mathrm{high}})$ is the minimal finite-state memory preventing high-frequency actuation deadlock.

### 2.6 Actuator: Exponential Relaxation

When $S_t = 1$, let $\tau$ be steps since activation ($t - t_{\mathrm{trigger}}$). Temperature for step $t{+}1$:
$$
T_{t+1} = T_{\mathrm{anchor}} + \bigl(T_{\mathrm{critical}} - T_{\mathrm{anchor}}\bigr)\, e^{-\lambda \tau}
$$
with $T_{\mathrm{anchor}} = 0.80$, $T_{\mathrm{critical}} = 0.65$, $\lambda = 0.15$. When $S_t = 0$, $T_{t+1} = T_{\mathrm{critical}}$.

**Internal validity.** The only deliberate difference between arms in §2.7 is this law; prompt, model, $K$, and step budget are matched.

### 2.7 V9.0 Closed-Loop Evaluation Protocol

| Parameter | Value |
|-----------|-------|
| Closed-loop prompt | P2 class: *"Why do humans use mathematics to describe nature?"* |
| Trajectories | 5 independent runs per arm |
| Horizon | 80 tokens per trajectory (`num_predict=1` loop) |
| **Controlled** | Schmitt + relaxation (§2.5–2.6) |
| **Baseline** | Fixed $T \equiv 0.65$ |
| Primary metrics | Per-step $H_t$; peak/mean/std; gate duty $\frac{1}{N}\sum \mathbb{1}[S_t{=}1]$ |

**Statistical reporting.** Descriptive statistics on pooled steps ($N{=}400$ per arm). Inferential tests (bootstrap CIs on peak reduction) recommended before journal submission.

**External validity (scope statement).** Results certify the actuator under one local 7B model and one scientific-expository prompt; generalization requires re-calibrating $(\theta_{\mathrm{low}}, \theta_{\mathrm{high}}, T_{\mathrm{critical}})$ on new families. P1–P10 probes provide **existence proof** that heterogeneous regimes are ubiquitous, not that one prompt subsumes all.

---

## 3. Results (Summary)

### 3.1 Non-Monotonic $H(T)$ and Risk Peak at $T{=}0.65$

Entropy vs. temperature is non-monotonic (catastrophic dips near $T{=}0.75$ in aggregate scans). Risk $R(T)$ peaks at $T{=}0.65$, aligning with $T_{\mathrm{critical}}$.

### 3.2 Hysteresis Requires Stateful Control

Heating and cooling risk curves form a bounded hysteresis loop; risk at $T{=}0.65$ is high on heating but not on cooling, and vice versa at $T{=}0.80$.

### 3.3 Prompt-Conditioned Regimes

Regime density is dominated by COLLAPSE with rare high-leverage TRANSITION/DIFFUSE samples. P2/P8 drive extreme $\chi^2$ tails; per-prompt $\chi^2(T)$ curves (P5–P10 supplied) show critical bands at task-specific $T$.

### 3.4 V9.0 Tail Clipping (Pooled $N{=}400$)

| Metric | Controlled | Baseline | $\Delta$ |
|--------|------------|----------|----------|
| Mean $H$ | 0.611 | 0.633 | $-3.4\%$ |
| Std $H$ | 0.575 | 0.602 | $-4.6\%$ |
| **Peak $H$** | **2.289** | **2.644** | **$-13.4\%$** |
| Gate ON | 217/400 (54.3%) | — | — |

Fig. 1 (three-panel): entropy vs. thresholds, $S(t)$, relaxation ramps of $T(t)$.  
Fig. 2: controlled vs. baseline entropy traces; baseline global peak at step $\approx 15$ ($H{\approx}2.64$) attenuated under control.

---

## 4. Validity Discussion (Reviewer Defense)

| Threat | Mitigation in this work |
|--------|------------------------|
| Truncated entropy | Same $K{=}20$ estimator both arms; comparative peaks/means |
| Unfair baseline | Baseline is deployed setpoint $T{=}0.65$ from risk calibration, not a weak strawman |
| Overfitting thresholds | $\theta$ from V8.4 P2 bootstrap, not V9.0 trajectory labels |
| Single prompt in V9.0 | P1–P10 probes establish generality of *need*; V9.0 demonstrates *mechanism* |
| Engineering-only | Hysteresis + non-monotonicity are measured phenomena preceding controller design |

**Claim boundary (honest scope).** V9.0 is a **streaming safety layer** that clips entropy shocks; it is not proven to improve human preference scores or downstream task accuracy in this release.

---

## 5. Reproducibility Statement

1. Install Ollama ≥ 0.12.11; pull `qwen2.5:7b`.
2. `pip install numpy matplotlib` (+ `ollama` optional; HTTP path in `ollama_utils.py`).
3. `python v9.0_closed_loop.py` → regenerates JSON + figures.
4. Archive: commit hash, `closed_loop_data.json`, both PNGs, and this manuscript version ID.

**Suggested deposition:** Zenodo DOI for data + GitHub for code; arXiv cs.LG / cs.AI for preprint.

---

## 6. References (Placeholder)

- Ollama logprobs API documentation (v0.12.11+).
- [Add: Shannon entropy in language modeling, decoding control, hysteresis/control theory citations.]

---

## Figure List (for upload bundle)

| ID | File | Content |
|----|------|---------|
| V8 | `entropy_vs_T.png`, `risk_vs_T.png`, `hysteresis.png`, … | Open-loop phenomenology |
| V8 | `chi2_by_prompt.png`, `phase_diagram_P*.png` | Prompt heterogeneity |
| V9 | `fig1_schmitt_gate.png` | Schmitt + relaxation actuation |
| V9 | `fig2_entropy_comparison.png` | Controlled vs. baseline |

---

*End of manuscript draft.*
