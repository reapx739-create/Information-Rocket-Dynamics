# Prompt-Conditioned Distributional Regimes and Schmitt-Trigger Closed-Loop Temperature Control for Streaming LLM Inference

**Draft:** Phase 2 formal manuscript v0.2 (Option C)  
**Repository:** https://github.com/reapx739-create/Information-Rocket-Dynamics

---

## Abstract

We study **inference-time distributional dynamics** in autoregressive large language models (LLMs). First, using large-scale logprob probes across sixteen temperatures and ten prompt families ($n{=}13{,}120$ state vectors), we show that **temperature is not a monotonic entropy dial**: Shannon entropy, $\chi^2$ divergence from a fixed baseline distribution, and a path-dependent **risk** functional exhibit non-monotonic landscapes, heating–cooling **hysteresis**, and **prompt-conditioned phase heterogeneity** (collapse vs.\ oscillatory regimes). Prompts with semantic freedom (reasoning, philosophy) reach $\chi^2/df$ up to $2.49$ and $70\%$ trajectory bifurcation at $T{=}0.65$, whereas factual prompts remain temperature-invariant. Second, motivated by these findings, we deploy **V9.0**, a **model-free** streaming controller combining a **dual-threshold Schmitt trigger** on entropy trend momentum and an **exponential temperature relaxation** actuator. On local **Qwen2.5-7B** (Q4\_K\_M, Ollama), V9.0 reduces **peak Shannon entropy by 13.4\%** vs.\ a fixed-$T{=}0.65$ baseline while lowering mean entropy by only **3.4\%**, with Schmitt activation on **54.3\%** of token steps. Code, step-level logs, and figures are publicly released.

**Keywords:** LLM inference control; prompt-conditioned regimes; Shannon entropy; Schmitt trigger; hysteresis; Ollama logprobs

---

## 1. Introduction

Decoding temperature $T$ is the default actuator for trading fluency against diversity. Practitioners often assume that increasing $T$ smoothly increases next-token entropy $H$. We show this assumption fails systematically once streaming logprobs are measured at scale: identical $T$ can yield disjoint entropy–divergence manifolds depending on **prompt cognitive type** and **thermodynamic history** (heating vs.\ cooling).

This paper makes two linked contributions:

1. **Empirical characterization (V8.x).** A reproducible probe battery quantifying non-monotonic $H(T)$, risk peaks at $T{\approx}0.65$, hysteresis loops, and prompt-level regime taxonomy (COLLAPSE / MODERATE / OSCILLATORY).

2. **Closed-loop actuation (V9.0).** A lightweight, graph-external controller using Schmitt gating and exponential relaxation, validated on token-level local inference with released traces.

**Scope.** V9.0 is a **streaming safety layer** targeting extreme entropy tails; we do not claim human-preference or downstream task gains in this release.

---

## 2. Methods

### 2.1 Overview: Two-Stage Experimental Design

| Stage | Goal | Model (as run) | Output |
|-------|------|----------------|--------|
| **V8.x probes** | Map open-loop thermodynamics | DeepSeek V4 Pro (Table 1 archive) | Regime taxonomy, $\chi^2(T)$, hysteresis |
| **V9.0 control** | Validate closed-loop actuator | Qwen2.5-7B Q4\_K\_M via Ollama 0.24.0 | 400+400 step JSON log, Figs. 9–10 |

Both stages share the same **online estimators** (§2.2–2.3); V9.0 thresholds are calibrated on V8.4 (P2, $T{=}0.65$) and never fit to V9.0 trajectory labels.

### 2.2 Online Shannon Entropy (Truncated Top-$K$)

At step $t$, the API returns `top_logprobs` $\mathcal{L}_t$ ($K{=}20$):
$$
\tilde{p}_i = \frac{\exp(\ell_i)}{\sum_{j \in \mathcal{L}_t} \exp(\ell_j)}, \qquad
H_t = -\sum_{i \in \mathcal{L}_t} \tilde{p}_i \log \tilde{p}_i .
$$
$H_t$ is a **comparative** surrogate (tail mass outside $\mathcal{L}_t$ omitted). V9.0 arms use the **same** $K$.

**API note.** Ollama requires `logprobs: true` and `top_logprobs: 20` at the **HTTP body top level**, with `num_predict: 1` for token-wise closed-loop runs.

### 2.3 $\chi^2$ Distributional Shift and Risk

Reference distribution $\mathbf{p}^{(\mathrm{ref})}$ at **$T_{\mathrm{ref}}{=}0.80$** (same prompt, 200-token window, $df{=}199$):
$$
\chi^2_t = \sum_{k} \frac{(p_{t,k} - p^{(\mathrm{ref})}_k)^2}{p^{(\mathrm{ref})}_k}.
$$
Report $\chi^2/df$ ($\mathbb{E} \approx 1$ under no shift). **Regimes:** OSCILLATORY if $\geq 50\%$ trajectory divergence at $T{=}0.65$; COLLAPSE if $\leq 10\%$; else MODERATE.

**Risk:** $R(T) = |\Delta \chi^2 / \Delta T|$; global maximum at $T{\approx}0.65$ ($R{\approx}0.20$) sets $T_{\mathrm{critical}}$.

**Hysteresis:** independent heating ($T\uparrow$) and cooling ($T\downarrow$) traversals.

### 2.4 Prompt Suite (P1–P10)

Ten prompts: factual (P1), reasoning (P2/P2b), coding (P3), evolution summary (P4), creative (P5), physics tips (P6), translation (P7), philosophy (P8), control systems (P9), transformers (P10). Per-prompt $\chi^2(T)$ curves and $(H,\chi^2)$ phase diagrams are colored by $T$.

### 2.5 Schmitt-Trigger Controller (V9.0)

$\mu_{\mathrm{crit}}{=}0.28$, $\sigma_{\mathrm{crit}}{=}0.04$ (V8.4 bootstrap, P2, $T{=}0.65$, $n{=}30$):
$\theta_{\mathrm{low}}{=}\mu_{\mathrm{crit}}$, $\theta_{\mathrm{high}}{=}\mu_{\mathrm{crit}}+1.645\sigma_{\mathrm{crit}}{\approx}0.346$.

Momentum: $M_t = \beta(H_t - H_{t-1}) + (1-\beta)M_{t-1}$, $\beta{=}0.18$.

Gate $S_t$: activate on $M_t>0 \land H_t>\theta_{\mathrm{high}}$; release on $M_t\leq 0 \land H_t\leq\theta_{\mathrm{low}}$.

Actuator: $T_{t+1}=T_{\mathrm{critical}}$ if $S_t{=}0$; else $T_{\mathrm{anchor}}+(T_{\mathrm{critical}}-T_{\mathrm{anchor}})e^{-\lambda\tau}$ with $T_{\mathrm{anchor}}{=}0.80$, $\lambda{=}0.15$.

### 2.6 V9.0 Evaluation Protocol

P2-class prompt; 5$\times$80 tokens; controlled vs.\ fixed $T{=}0.65$; RTX 4070 Laptop, Ollama `localhost:11434`.

---

## 3. Results

### 3.1 Open-Loop Thermodynamics: Entropy vs.\ Temperature (Figure 1)

**Figure 1** (`entropy_vs_T`) plots $H(T)$ on a dense grid from $T{=}0.2$ to $1.4$. Contrary to the monotonic narrative, $H$ **does not track $T$ linearly**. The curve exhibits multiple local extrema: a rise toward $T{\approx}0.3$, fluctuations through the mid-range, a **global minimum near $T{\approx}0.75$** ($H{\approx}0.100$), and renewed structure beyond $T{=}1.0$. This falsifies treating temperature as a one-dimensional “randomness knob” without measuring the realized distribution.

**Interpretation.** At fixed architecture, changing $T$ can re-route generation among **alternative semantic tracks**—some more collapsed than neighbors—rather than uniformly blurring logits.

### 3.2 Critical Sensitivity Band (Figure 2)

**Figure 2** (`risk_vs_T`) shows the risk functional $R(T)=|\Delta\chi^2/\Delta T|$. After low-risk plateaus at extreme temperatures, $R$ spikes sharply in the mid-range, with a **global maximum at $T{\approx}0.65$** ($R{\approx}0.20$). Smaller secondary peaks appear near $T{\approx}0.3$ and $0.5$; post-peak, $R$ collapses at $T{\approx}0.7$ before a moderate bump near $T{\approx}0.9$.

**Design consequence.** $T_{\mathrm{critical}}{=}0.65$ for V9.0 is anchored to this **empirical instability locus**, not to V9.0 closed-loop tuning.

### 3.3 Path-Dependent Hysteresis (Figure 3)

**Figure 3** (`hysteresis`) overlays **heating** (ascending $T$) and **cooling** (descending $T$) risk trajectories. The curves enclose a large **topological envelope**: path matters.

- At **$T{\approx}0.65$**, heating carries elevated risk ($R{\approx}0.20$) while cooling is comparatively safe.
- At **$T{\approx}0.80$**, the ordering **inverts**: cooling exhibits the loop’s strongest delayed-risk pulse ($R{\approx}0.20$), while heating is in a safer band.

**Control consequence.** A memoryless map $T{=}f(H_t)$ would **chatter** at envelope boundaries; a **Schmitt trigger** with $(\theta_{\mathrm{low}},\theta_{\mathrm{high}})$ is the minimal stateful stabilizer.

### 3.4 Prompt-Conditioned $\chi^2$ Tails (Figure 4)

**Figure 4** (`chi2_by_prompt`) boxplots $\chi^2$ by prompt ID. P1, P3, P5, P6, P7, P10 show **near-zero medians** with tight support—**collapse-class** behavior. **P2** displays extreme outliers up to $\chi^2{\approx}9.5$ despite a low median. **P8** combines a depressed median with a heavy lower tail (Top-1 down to ${\sim}0.76$ in companion plots). P4 and P9 show intermediate spread.

**Table 1** aggregates regime labels (V8.5; $n{=}13{,}120$):

| Prompt | Regime | top-1 | $H$ | Bifurc.\% @0.65 | $\chi^2/df$ |
|--------|--------|-------|-----|-----------------|-------------|
| P1 factual | COLLAPSE | 0.984 | 0.058 | 0% | 0.35 |
| P3 coding | MODERATE | 0.914 | 0.260 | 20% | 0.69 |
| P2 reasoning | OSCILLATORY | 0.919 | 0.248 | 70% | 0.84 |
| P2b variant | OSCILLATORY | 0.909 | 0.241 | 70% | 0.29 |
| P8 philosophy | OSCILLATORY | 0.923 | 0.238 | 70% | **2.49** |

Temperature modulates distributions **only when prompts permit semantic freedom**; P8’s $\chi^2/df{=}2.49$ is $\sim 15\sigma$ above the null.

### 3.5 Phase Manifold: Reasoning Prompt P2 (Figure 5)

**Figure 5** (phase diagram, P2: *“Why do humans use mathematics to describe nature?”*) scatters $(H,\chi^2)$ colored by $T$. A **low-entropy cluster** sits near the origin for many temperatures. **High-$\chi^2$ outliers** appear at low $T$ (purple, $T{\sim}0.5$): e.g.\ $(H,\chi^2){\approx}(0.08,6.0)$ and $(0.93,9.5)$. High-$T$ points (yellow) can simultaneously show **low $\chi^2$** at moderate $H$—identical $T$ does not imply identical phase.

This panel is the **scientific motivation** for the V9.0 closed-loop prompt class.

### 3.6 Phase Manifold: Philosophy Prompt P8 (Figure 6)

**Figure 6** (P8: *“What is consciousness?”*) shows a dominant low-$(H,\chi^2)$ cluster plus a **mid-$T$ outlier** at $(H,\chi^2){\approx}(0.65,4.5)$ (reddish, $T{\approx}0.8$). Per-prompt $\chi^2(T)$ for P8 exhibits **explosive error bars** at $T{\in}\{0.6,0.9\}$—local **critical bands** where variance, not just mean shift, signals phase transition.

### 3.7 Macro Regime Mass (Figure 7)

**Figure 7** (`regime_density`) counts state labels across the probe archive. **COLLAPSE** dominates (${\sim}3000$ samples) vs.\ smaller STABLE, DIFFUSE, and TRANSITION masses. Open-loop generation spends most tokens in **high-certainty** regions; controllers must focus on **rare, high-leverage** excursions rather than rewriting bulk behavior.

### 3.8 Top-1 Probability Tails (Figure 8)

**Figure 8** (`top1_by_prompt`) mirrors Figure 4 at the **confidence** scale. Collapse prompts pin $P_1(\text{top}){\approx}1.0$; P2’s whiskers reach ${\sim}0.63$; P8’s interquartile range drops to ${\sim}0.76$–$0.96$. Together with Figures 4–6, this supports the title claim: **prompt-conditioned distributional regimes**.

### 3.9 V9.0 Actuation Dynamics (Figure 9)

**Figure 9** (`fig1_schmitt_gate`, Qwen2.5-7B, 400 controlled steps) validates the deployed law (§2.5).

- **Top:** $H(t)$ repeatedly breaches $\theta_{\mathrm{high}}$ (${\approx}0.346$) and relaxes toward $\theta_{\mathrm{low}}$ (${=}0.28$), with shocks up to $H{\approx}2.3$.
- **Middle:** $S(t)$ shows extended CONTROL blocks without millisecond chatter—hysteresis working as designed.
- **Bottom:** On activation, $T(t)$ rises along **smooth exponential ramps** toward $T_{\mathrm{anchor}}{=}0.80$, then resets to $T_{\mathrm{critical}}{=}0.65$ in SAFE mode—confirming Eq.~(actuator) inside the autoregressive loop.

Gate duty: **217/400 (54.3\%)**. Temperature range: **0.650–0.786**.

### 3.10 Tail Clipping vs.\ Baseline (Figure 10)

**Figure 10** (`fig2_entropy_comparison`) overlays controlled (blue) and baseline (red) entropy on matched token budgets.

| Metric | Controlled | Baseline | $\Delta$ |
|--------|------------|----------|----------|
| Mean $H \pm$ std | $0.611 \pm 0.576$ | $0.633 \pm 0.603$ | $-3.4\%$ |
| Peak $H$ | **2.289** | 2.644 | **$-13.4\%$** |
| Gate ON | 54.3\% | — | — |

Baseline **global peak** occurs at step ${\approx}15$ ($H{=}2.644$); controlled attenuates concurrent excursions. Secondary baseline shocks (steps ${\approx}70,130,230,360$) are similarly trimmed. Bulk mean shift remains small: the controller behaves as a **seatbelt on the upper tail**, not a global creativity suppressor.

---

## 4. Discussion

**Causal chain.** Non-monotonic $H(T)$ (Fig. 1) $\Rightarrow$ reject linear temperature schedules. Risk peak and hysteresis (Figs. 2–3) $\Rightarrow$ require **stateful** Schmitt gating. Prompt heterogeneity (Figs. 4–8) $\Rightarrow$ require **streaming** adaptation. V9.0 (Figs. 9–10) $\Rightarrow$ mechanism with **13.4\%** peak-entropy reduction and **3.4\%** mean shift.

**Model split.** V8 characterization (DeepSeek V4 Pro) and V9 deployment (Qwen2.5-7B) test **general control architecture** under resource constraints; recalibration of $(\theta,T_{\mathrm{critical}})$ is expected on model change.

**Limitations.** Top-$K$ entropy; no human evaluation; single-prompt closed-loop; bootstrap CIs pending; V8 figure paths external to minimal GitHub bundle.

**Future work.** Unified probe/control model; $K$-sensitivity; multi-prompt V9.1; correlate peak-$H$ with hallucination annotations.

---

## 5. Related Work

**Decoding and temperature.** Boltzmann-style sampling and temperature scaling (Ackley et al., 1985; Holtzman et al., 2020) treat $T$ as a **static** knob. Renze & Guven (2024) study temperature effects on reasoning tasks but not streaming closed-loop actuation. We measure **token-level** $H_t$ and $\chi^2_t$ and feed them back online.

**Uncertainty and calibration.** Modern networks miscalibrate even when confident (Guo et al., 2017); selective prediction abstains under uncertainty (Geifman & El-Yaniv, 2017). Surveys consolidate UQ for LLMs (Hu et al., 2024). We repurpose truncated-logprob entropy as a **control input**, not a post-hoc calibration plot.

**Hallucination and consistency.** SelfCheckGPT (Manakul et al., 2023) and snowballing error analyses (Zhang et al., 2023) target factual drift. Context-aware decoding reduces hallucination by contrasting contexts (Shi et al., 2024). We contribute a **thermodynamic** framing: extreme entropy shocks visible in open-loop phase diagrams before task labels are available.

**Inference-time control.** Contrastive and controlled decoding modify logits at runtime (Li et al., 2023; Mudgal et al., 2024). V9.0 is **model-free**, **graph-external**, and actuates only **temperature**—compatible with any base model exposing logprobs (Ollama, 2025).

**Prompt sensitivity.** Placement and formatting strongly condition behavior (Sclar et al., 2023; Mizrahi et al., 2024). We quantify this as a **regime taxonomy** (COLLAPSE / OSCILLATORY) with $\chi^2/df$ up to $2.49$ on philosophy prompts.

**Control and hysteresis.** Schmitt triggers and nonlinear actuation are classical tools for noise-immune switching (Ogata, 2010). We argue LLM inference exhibits analogous **path-dependent risk envelopes**, motivating finite-state gating rather than memoryless $T=f(H)$ maps.

---

## 6. Reproducibility

Repository: https://github.com/reapx739-create/Information-Rocket-Dynamics

```bash
git clone https://github.com/reapx739-create/Information-Rocket-Dynamics.git
cd Information-Rocket-Dynamics/paper
pip install pandas numpy matplotlib
python generate_v8_figures.py    # needs ../v84_results/v84_scan.csv
cd ../code && python v9.0_closed_loop.py   # Ollama + qwen2.5:7b
```

**Figure bundle:** `paper/figures/` — Figs. 1–8 (V8), 9–10 (V9).  
**Data:** `v84_results/v84_scan.csv`, `code/closed_loop_data.json`.

---

## References

1. Ackley, Hinton, & Sejnowski (1985). Boltzmann machine learning. *Cognitive Science*.  
2. Geifman & El-Yaniv (2017). Selective classification. *NeurIPS*.  
3. Guo et al. (2017). Calibration of modern neural networks. *ICML*.  
4. Holtzman et al. (2020). Neural text degeneration. *ICLR*.  
5. Li et al. (2023). Contrastive decoding. *ACL*.  
6. Manakul et al. (2023). SelfCheckGPT. *arXiv:2303.08896*.  
7. Mizrahi et al. (2024). Multi-prompt LLM evaluation. *TACL*.  
8. Mudgal et al. (2024). Controlled decoding from LMs. *arXiv*.  
9. Ogata (2010). *Modern Control Engineering*. Prentice Hall.  
10. Ollama Project (2025). Logprobs API. https://github.com/ollama/ollama  
11. Renze & Guven (2024). Sampling temperature and problem solving. *arXiv:2402.05201*.  
12. Sclar et al. (2023). Prompt placement sensitivity. *EMNLP*.  
13. Zhang et al. (2023). Hallucination snowballing. *arXiv:2305.13534*.  
14. Hu et al. (2024). UQ in LLMs survey. *arXiv*.  
15. Shi et al. (2024). Context-aware decoding. *ACL Findings*.

---

## Supplementary Figures (generated, optional for appendix)

- `top1_vs_T.png` — non-monotonic Top-1 vs.\ $T$  
- `chi2_vs_T.png` — aggregate $\chi^2(T)$ with error bars  
- `dynamics_plane.png` — $|\Delta\chi^2|$ vs.\ $|\Delta H|$  
- `phase_diagram.png` — pooled phase diagram over all prompts  

---

*End of Phase 2 formal draft v0.3*
